<template>
  <div class="container">
    <archive />
  </div>
</template>

<script>
import Archive from '~/components/Archive.vue'
export default {
  components: {
    Archive
  }
}
</script>

<style scoped></style>
