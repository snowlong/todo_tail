<template>
  <div class="w-full max-w-sm">
    <h1 class="title"></h1>
    <div>
      <ul class="flex flex-col bg-gray-200">
        <li class="text-center px-4 py-2 m-2">
          <label for="">
            <input type="text" />
          </label>
        </li>
        <li>aaa</li>
        <li>aaa</li>
        <li>aaa</li>
      </ul>
    </div>
    <div>
      <div class="flex items-center border-2 borader-tead-500 rounded-lg py-2">
        <input
          type="text"
          class="appearance-none bg-transparent borde-none w-full text-gray-700 mr-3 py-1 px-2 leading-tight focus:outline-none"
          placeholder="タスクを入力してください"
        />
      </div>
    </div>

    <button
      class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
    >
      Button
    </button>
  </div>
</template>
